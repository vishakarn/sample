import { Component, ViewChild } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  @ViewChild('popover') popover:any;
  isOpen = false;  

  constructor() {}


  openPopover(e: Event) {
    this.popover.event = e;
    this.isOpen = true;
  }

}
